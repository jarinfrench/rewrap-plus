CONFIG = {
    "host": "localhost",
    "port": "5432",
}
